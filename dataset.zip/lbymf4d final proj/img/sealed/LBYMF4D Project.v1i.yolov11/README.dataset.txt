# LBYMF4D Project > 2025-03-31 2:37pm
https://universe.roboflow.com/de-la-salle-university-3waz6/lbymf4d-project

Provided by a Roboflow user
License: CC BY 4.0

